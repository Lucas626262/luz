package com.lanterna.luz2

import android.os.Bundle
import android.os.Handler
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraCharacteristics
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private lateinit var cameraId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Inicializa o CameraManager e pega o ID da câmera
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            // Certificando-se de que o tipo da variável cameraId seja claramente inferido
            cameraId = cameraManager.cameraIdList.first {
                cameraManager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }

        // Configura o listener para o botão que liga a lanterna
        val button: Button = findViewById(R.id.button)
        button.setOnClickListener {
            turnOnFlashlightForOneSecond()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Função para ligar a lanterna por 1 segundo
    private fun turnOnFlashlightForOneSecond() {
        try {
            // Liga a lanterna
            cameraManager.setTorchMode(cameraId, true)

            // Usando Handler para desligar após 1 segundo
            Handler().postDelayed({
                // Desliga a lanterna após 1 segundo
                cameraManager.setTorchMode(cameraId, false)
            }, 1000)  // 1000 milissegundos = 1 segundo
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }
}
